package coupons;

import example.coupons.controller.CouponController;
import example.coupons.model.Coupon;
import example.coupons.model.CouponDTO;
import example.coupons.service.CouponService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CouponControllerTest {

    @Mock
    private CouponService couponService;

    @InjectMocks
    private CouponController couponController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(couponController).build();
    }

    @Test
    void testCreateCoupon() throws Exception {
        // Prepare the DTO
        CouponDTO couponDTO = new CouponDTO();
        couponDTO.setCode("SAVE10");
        couponDTO.setType("cart-wise");
        couponDTO.setDiscountDetails("10% off on carts over Rs. 100");
        couponDTO.setConditions("Cart total > 100");
        couponDTO.setExpirationDate(LocalDateTime.now().plusDays(10));
        couponDTO.setMinimumCartValue(100);

        // Mock the service method
        doNothing().when(couponService).createCoupon(any(CouponDTO.class));

        // Perform the request
        mockMvc.perform(post("/coupons")
                        .contentType("application/json")
                        .content("{ \"code\": \"SAVE10\", \"type\": \"cart-wise\", \"discountDetails\": \"10% off on carts over Rs. 100\", \"conditions\": \"Cart total > 100\", \"expirationDate\": \"" + LocalDateTime.now().plusDays(10).toString() + "\", \"minimumCartValue\": 100 }"))
                .andExpect(status().isCreated())
                .andExpect(content().string("Coupon created successfully"));
    }

    @Test
    void testGetAllCoupons() throws Exception {
        Coupon coupon = new Coupon();
        coupon.setId(1L);
        coupon.setType("cart-wise");
        coupon.setDiscountDetails("10% off on carts over Rs. 100");
        coupon.setConditions("Cart total > 100");

        when(couponService.getAllCoupons()).thenReturn(Collections.singletonList(coupon));

        mockMvc.perform(get("/coupons"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].type").value("cart-wise"));
    }

    @Test
    void testGetCouponById() throws Exception {
        Coupon coupon = new Coupon();
        coupon.setId(1L);
        coupon.setType("cart-wise");
        coupon.setDiscountDetails("10% off on carts over Rs. 100");
        coupon.setConditions("Cart total > 100");

        when(couponService.getCouponById(anyLong())).thenReturn(Optional.of(coupon));

        mockMvc.perform(get("/coupons/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.type").value("cart-wise"));
    }

    @Test
    void testUpdateCoupon() throws Exception {
        // Create a CouponDTO instance with updated details
        CouponDTO couponDTO = new CouponDTO();
        couponDTO.setCode("SAVE10");
        couponDTO.setType("cart-wise");
        couponDTO.setDiscountDetails("15% off on carts over Rs. 150");
        couponDTO.setConditions("Cart total > 150");
        couponDTO.setExpirationDate(LocalDateTime.now().plusDays(10));
        couponDTO.setMinimumCartValue(150);

        // Create an updated Coupon instance to be returned by the service
        Coupon updatedCoupon = new Coupon();
        updatedCoupon.setId(1L);
        updatedCoupon.setType("cart-wise");
        updatedCoupon.setDiscountDetails("15% off on carts over Rs. 150");
        updatedCoupon.setConditions("Cart total > 150");

        // Mock the service method
        when(couponService.updateCoupon(anyLong(), any())).thenReturn(updatedCoupon);

        // Perform the update coupon request
        mockMvc.perform(put("/coupons/1")
                        .contentType("application/json")
                        .content("{ \"code\": \"SAVE10\", \"type\": \"cart-wise\", \"discountDetails\": \"15% off on carts over Rs. 150\", \"conditions\": \"Cart total > 150\", \"expirationDate\": \"" + LocalDateTime.now().plusDays(10) + "\", \"minimumCartValue\": 150 }"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.discountDetails").value("15% off on carts over Rs. 150"));
    }

    @Test
    void testDeleteCoupon() throws Exception {
        doReturn(true).when(couponService).deleteCoupon(anyLong());

        mockMvc.perform(delete("/coupons/1"))
                .andExpect(status().isNoContent());

        verify(couponService).deleteCoupon(1L);
    }
}
