package example.coupons.service;

import example.coupons.model.Cart;
import example.coupons.model.Coupon;
import example.coupons.model.CouponDTO;
import example.coupons.model.CouponRequest;
import example.coupons.repository.CouponRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CouponService {

    private static final Logger logger = LoggerFactory.getLogger(CouponService.class);

    private final CouponRepository couponRepository;

    @Autowired
    public CouponService(CouponRepository couponRepository) {
        this.couponRepository = couponRepository;
    }

    public ResponseEntity<String> createCoupon(CouponDTO couponDTO) {
        try {
            // Manual validation
            validateCouponDTO(couponDTO);

            // Convert DTO to entity
            Coupon coupon = new Coupon();
            coupon.setCode(couponDTO.getCode());
            coupon.setType(couponDTO.getType());
            coupon.setExpirationDate(couponDTO.getExpirationDate());
            coupon.setMinimumCartValue(couponDTO.getMinimumCartValue());
            coupon.setDiscountDetails(couponDTO.getDiscountDetails());
            coupon.setConditions(couponDTO.getConditions());
            coupon.setApplicableCategories(couponDTO.getApplicableCategories());

            // Save the coupon
            couponRepository.save(coupon);

            // Return a success response
            return new ResponseEntity<>("Coupon created successfully", HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            // Return a bad request response with validation error
            logger.error("Validation error: {}", e.getMessage());
            return new ResponseEntity<>("Invalid input: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            // Return a bad request response with general error
            logger.error("Error creating coupon: {}", e.getMessage(), e);
            return new ResponseEntity<>("Error creating coupon: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private void validateCouponDTO(CouponDTO couponDTO) {
        if (couponDTO.getCode() == null || couponDTO.getCode().isEmpty()) {
            throw new IllegalArgumentException("Code must not be empty");
        }
        if (couponDTO.getType() == null || couponDTO.getType().isEmpty()) {
            throw new IllegalArgumentException("Type must not be empty");
        }
        if (couponDTO.getExpirationDate() == null) {
            throw new IllegalArgumentException("Expiration date must not be null");
        }
        if (couponDTO.getExpirationDate().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Expiration date must be in the future");
        }
        if (couponDTO.getMinimumCartValue() < 0) {
            throw new IllegalArgumentException("Minimum cart value must not be negative");
        }
    }

    public List<Coupon> getAllCoupons() {
        return couponRepository.findAll();
    }

    public Optional<Coupon> getCouponById(Long id) {
        return couponRepository.findById(id);
    }

    public Coupon updateCoupon(Long id, Coupon couponDetails) {
        return couponRepository.findById(id)
                .map(coupon -> {
                    coupon.setType(couponDetails.getType());
                    coupon.setDiscountDetails(couponDetails.getDiscountDetails());
                    coupon.setConditions(couponDetails.getConditions());
                    coupon.setExpirationDate(couponDetails.getExpirationDate());
                    coupon.setMinimumCartValue(couponDetails.getMinimumCartValue());
                    coupon.setApplicableCategories(couponDetails.getApplicableCategories());
                    return couponRepository.save(coupon);
                })
                .orElse(null);
    }

    public boolean deleteCoupon(Long id) {
        if (couponRepository.existsById(id)) {
            couponRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Coupon> getApplicableCoupons() {
        return getApplicableCoupons(0.0);
    }

    public List<Coupon> getApplicableCoupons(double cartValue) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        List<Coupon> allCoupons = getAllCoupons();
        List<Coupon> applicableCoupons = new ArrayList<>();

        for (Coupon coupon : allCoupons) {
            if (coupon.getExpirationDate().isAfter(currentDateTime) || coupon.getExpirationDate().isEqual(currentDateTime)) {
                if (cartValue >= coupon.getMinimumCartValue()) {
                    applicableCoupons.add(coupon);
                }
            }
        }

        return applicableCoupons;
    }

    public Cart applyCouponToCart(Long id, Cart cart) {
        if (cart == null) {
            throw new IllegalArgumentException("Cart cannot be null.");
        }

        // Retrieve the coupon and apply it if found
        Coupon coupon = couponRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Coupon not found."));

        // Check if the coupon is applicable to the cart
        if (coupon.isApplicable(cart)) {
            double discount = coupon.calculateDiscount(cart);
            cart.applyDiscount(discount);
            return cart; // Return the updated cart with the applied discount
        } else {
            throw new IllegalArgumentException("Coupon is not applicable to the cart.");
        }
    }


    public List<Coupon> findApplicableCoupons(CouponRequest couponRequest) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime requestExpirationDate = couponRequest.getExpirationDate();

        logger.debug("Received CouponRequest: {}", couponRequest);

        List<Coupon> allCoupons = couponRepository.findAll();

        List<Coupon> applicableCoupons = allCoupons.stream()
                .filter(coupon -> {
                    boolean isApplicable = coupon.getCode().equals(couponRequest.getCode()) &&
                            coupon.getType().equals(couponRequest.getType()) &&
                            (coupon.getExpirationDate().isAfter(now) || coupon.getExpirationDate().isEqual(now)) &&
                            coupon.getMinimumCartValue() <= couponRequest.getMinimumCartValue() &&
                            (couponRequest.getApplicableCategories() == null ||
                                    couponRequest.getApplicableCategories().isEmpty() ||
                                    coupon.getApplicableCategories().stream()
                                            .anyMatch(couponRequest.getApplicableCategories()::contains));

                    logger.debug("Coupon {} applicability: {}", coupon, isApplicable);
                    return isApplicable;
                })
                .collect(Collectors.toList());

        logger.debug("Found applicable coupons: {}", applicableCoupons);

        return applicableCoupons;
    }
}
