package example.coupons.model;

import org.slf4j.Logger;
import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static example.coupons.controller.CouponController.logger;

@Entity
@Table(name = "coupon")
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String code;

    private String type;

    private LocalDateTime expirationDate;

    private double minimumCartValue;

    @ElementCollection
    @CollectionTable(name = "coupon_categories", joinColumns = @JoinColumn(name = "coupon_id"))
    @Column(name = "category")
    private List<String> applicableCategories = Collections.emptyList(); // Default empty list

    private String discountDetails;

    private String conditions;

    // Default Constructor
    public Coupon() {
    }

    // Constructor with parameters
    public Coupon(Long id, String code, String type, LocalDateTime expirationDate, double minimumCartValue, List<String> applicableCategories) {
        this.id = id;
        this.code = code;
        this.type = type;
        this.expirationDate = expirationDate;
        this.minimumCartValue = minimumCartValue;
        this.applicableCategories = applicableCategories != null ? applicableCategories : Collections.emptyList();
    }

    // Constructor with essential parameters
    public Coupon(Long id, String code, String type, LocalDateTime expirationDate) {
        this(id, code, type, expirationDate, 0.0, Collections.emptyList()); // Defaults
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDateTime getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDateTime expirationDate) {
        this.expirationDate = expirationDate;
    }

    public double getMinimumCartValue() {
        return minimumCartValue;
    }

    public void setMinimumCartValue(double minimumCartValue) {
        this.minimumCartValue = minimumCartValue;
    }

    public List<String> getApplicableCategories() {
        return applicableCategories;
    }

    public void setApplicableCategories(List<String> applicableCategories) {
        this.applicableCategories = applicableCategories != null ? applicableCategories : Collections.emptyList();
    }

    public String getDiscountDetails() {
        return discountDetails;
    }

    public void setDiscountDetails(String discountDetails) {
        this.discountDetails = discountDetails;
    }

    public String getConditions() {
        return conditions;
    }

    public void setConditions(String conditions) {
        this.conditions = conditions;
    }

    /**
     * Calculates the discount based on the provided cart.
     * To be overridden in subclasses to provide specific discount logic.
     *
     * @param cart The shopping cart to apply the discount to.
     * @return The calculated discount amount.
     */
    public double calculateDiscount(Cart cart) {
        return 0.0; // Default implementation; should be overridden
    }

    /**
     * Checks if the coupon is applicable to the provided cart.
     * To be overridden in subclasses to provide specific applicability logic.
     *
     * @param cart The shopping cart to check applicability.
     * @return True if the coupon is applicable, otherwise false.
     */
    public boolean isApplicable(Cart cart) {
        if (cart == null) {
            logger.debug("Cart is null, coupon is not applicable.");
            return false;
        }

        if (expirationDate == null || expirationDate.isBefore(LocalDateTime.now())) {
            logger.debug("Coupon expired or expirationDate is null: {}", expirationDate);
            return false;
        }

        Double totalAmount = cart.getTotalAmount();
        if (totalAmount == null || totalAmount < minimumCartValue) {
            logger.debug("Cart total amount {} is less than minimumCartValue {}", totalAmount, minimumCartValue);
            return false;
        }

        List<String> cartCategories = cart.getCategories();
        if (applicableCategories != null && !applicableCategories.isEmpty()) {
            logger.debug("Checking applicable categories: {}", applicableCategories);
            for (String category : applicableCategories) {
                if (cartCategories.contains(category)) {
                    logger.debug("Coupon is applicable for category: {}", category);
                    return true;
                }
            }
            logger.debug("No matching categories found, coupon is not applicable.");
            return false;
        }

        logger.debug("Coupon is applicable.");
        return true;
    }

    @Override
    public String toString() {
        return "Coupon{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", type='" + type + '\'' +
                ", expirationDate=" + expirationDate +
                ", minimumCartValue=" + minimumCartValue +
                ", applicableCategories=" + applicableCategories +
                ", discountDetails='" + discountDetails + '\'' +
                ", conditions='" + conditions + '\'' +
                '}';
    }
}
