package example.coupons.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a shopping cart containing multiple items.
 */
public class Cart {

    private List<CartItem> items;

    // Constructors
    public Cart() {
        this.items = new ArrayList<>();
    }

    public Cart(List<CartItem> items) {
        this.items = items;
    }

    // Getters and Setters
    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    /**
     * Calculates the total amount of the cart.
     *
     * @return The total amount of the cart.
     */
    public double getTotalAmount() {
        double totalAmount = 0;
        for (CartItem item : items) {
            totalAmount += item.getTotalPrice();  // Use getTotalPrice method
        }
        return totalAmount;
    }

    /**
     * Calculates the total value of the cart.
     *
     * @return The total value of the cart.
     */
    public double getTotalValue() {
        return getTotalAmount();  // Assuming total value is the same as total amount
    }

    /**
     * Applies a discount to the cart using the provided coupon.
     *
     */
    public void applyDiscount(double discount) {
        double totalAmount = getTotalAmount();
        double newTotal = totalAmount - discount;

        // Ensure that the total does not drop below zero
        double finalTotal = Math.max(newTotal, 0);
        System.out.println("Original Total: " + totalAmount);
        System.out.println("Discount Applied: " + discount);
        System.out.println("Final Total After Discount: " + finalTotal);

        // If you need to store the discounted total, you can add a field for it
        // For example:
        // this.discountedTotal = finalTotal;
    }

    /**
     * Gets the list of categories of items in the cart.
     *
     * @return The list of categories.
     */
    public List<String> getCategories() {
        List<String> categories = new ArrayList<>();
        for (CartItem item : items) {
            categories.add(item.getCategory());
        }
        return categories;
    }
}
