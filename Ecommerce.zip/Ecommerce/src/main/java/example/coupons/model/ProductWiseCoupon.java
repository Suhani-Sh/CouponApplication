package example.coupons.model;

import java.time.LocalDateTime;
import java.util.List;

public class ProductWiseCoupon extends Coupon {
    private double discountPercentage;
    private List<Long> applicableProductIds;

    // Constructors, Getters, Setters
    public ProductWiseCoupon() {}

    public ProductWiseCoupon(Long id, String code, LocalDateTime expirationDate, double discountPercentage, List<Long> applicableProductIds) {
        super(id, code, "product-wise", expirationDate);
        this.discountPercentage = discountPercentage;
        this.applicableProductIds = applicableProductIds;
    }

    public double getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public List<Long> getApplicableProductIds() {
        return applicableProductIds;
    }

    public void setApplicableProductIds(List<Long> applicableProductIds) {
        this.applicableProductIds = applicableProductIds;
    }

    @Override
    public double calculateDiscount(Cart cart) {
        double discount = 0;
        for (CartItem item : cart.getItems()) {
            if (applicableProductIds.contains(item.getProductId())) {
                discount += item.getPrice() * (discountPercentage / 100);
            }
        }
        return discount;
    }
}
