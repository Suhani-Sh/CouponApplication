package example.coupons.model;

import java.time.LocalDateTime;
import java.util.List;

public class BxGyCoupon extends Coupon {
    private int requiredQuantity;
    private int freeQuantity;
    private List<Long> buyProductIds;
    private List<Long> getProductIds;
    private int repetitionLimit;

    // Default Constructor
    public BxGyCoupon() {}

    // Constructor with parameters
    public BxGyCoupon(Long id, String code, LocalDateTime expirationDate, int requiredQuantity, int freeQuantity, List<Long> buyProductIds, List<Long> getProductIds, int repetitionLimit) {
        super(id, code, "bxgy", expirationDate, 0.0, null); // Assuming default minimumCartValue and applicableCategories
        this.requiredQuantity = requiredQuantity;
        this.freeQuantity = freeQuantity;
        this.buyProductIds = buyProductIds;
        this.getProductIds = getProductIds;
        this.repetitionLimit = repetitionLimit;
    }

    // Getters and Setters
    public int getRequiredQuantity() {
        return requiredQuantity;
    }

    public void setRequiredQuantity(int requiredQuantity) {
        this.requiredQuantity = requiredQuantity;
    }

    public int getFreeQuantity() {
        return freeQuantity;
    }

    public void setFreeQuantity(int freeQuantity) {
        this.freeQuantity = freeQuantity;
    }

    public List<Long> getBuyProductIds() {
        return buyProductIds;
    }

    public void setBuyProductIds(List<Long> buyProductIds) {
        this.buyProductIds = buyProductIds;
    }

    public List<Long> getGetProductIds() {
        return getProductIds;
    }

    public void setGetProductIds(List<Long> getProductIds) {
        this.getProductIds = getProductIds;
    }

    public int getRepetitionLimit() {
        return repetitionLimit;
    }

    public void setRepetitionLimit(int repetitionLimit) {
        this.repetitionLimit = repetitionLimit;
    }

    @Override
    public double calculateDiscount(Cart cart) {
        int buyCount = 0;
        int getCount = 0;

        for (CartItem item : cart.getItems()) {
            if (buyProductIds.contains(item.getProductId())) {
                buyCount += item.getQuantity();
            }
            if (getProductIds.contains(item.getProductId())) {
                getCount += item.getQuantity();
            }
        }

        int applicableTimes = Math.min(buyCount / requiredQuantity, repetitionLimit);
        double discount = 0;

        if (applicableTimes > 0) {
            for (CartItem item : cart.getItems()) {
                if (getProductIds.contains(item.getProductId())) {
                    int freeItems = Math.min(applicableTimes * freeQuantity, item.getQuantity());
                    discount += freeItems * item.getPrice();
                }
            }
        }

        return discount;
    }
}
