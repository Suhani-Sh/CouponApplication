package example.coupons.model;

import java.time.LocalDateTime;

public class CartWiseCoupon extends Coupon {
    private double discountPercentage;
    private double minimumCartAmount;

    // Constructors, Getters, Setters
    public CartWiseCoupon() {}

    public CartWiseCoupon(Long id, String code, LocalDateTime expirationDate, double discountPercentage, double minimumCartAmount) {
        super(id, code, "cart-wise", expirationDate, minimumCartAmount, null); // Passing minimumCartAmount and null for applicableCategories
        this.discountPercentage = discountPercentage;
        this.minimumCartAmount = minimumCartAmount;
    }


    public double getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public double getMinimumCartAmount() {
        return minimumCartAmount;
    }

    public void setMinimumCartAmount(double minimumCartAmount) {
        this.minimumCartAmount = minimumCartAmount;
    }

    @Override
    public double calculateDiscount(Cart cart) {
        if (cart.getTotalAmount() >= minimumCartAmount) {
            return cart.getTotalAmount() * (discountPercentage / 100);
        }
        return 0;
    }
}
