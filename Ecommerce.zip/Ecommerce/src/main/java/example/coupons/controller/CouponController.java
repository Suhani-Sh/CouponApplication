package example.coupons.controller;

import example.coupons.model.Cart;
import example.coupons.model.Coupon;
import example.coupons.model.CouponDTO;
import example.coupons.model.CouponRequest;
import example.coupons.service.CouponService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/coupons")
public class CouponController {

    public static final Logger logger = LoggerFactory.getLogger(CouponController.class);
    private final CouponService couponService;

    @Autowired
    public CouponController(CouponService couponService) {
        this.couponService = couponService;
    }

    // Test endpoint
    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return new ResponseEntity<>("Test Successful", HttpStatus.OK);
    }

    // Create a new coupon
    @PostMapping
    public ResponseEntity<String> createCoupon(@RequestBody CouponDTO couponDTO) {
        try {
            couponService.createCoupon(couponDTO);
            return new ResponseEntity<>("Coupon created successfully", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error creating coupon: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Get all coupons
    @GetMapping
    public ResponseEntity<List<Coupon>> getAllCoupons() {
        List<Coupon> coupons = couponService.getAllCoupons();
        return new ResponseEntity<>(coupons, HttpStatus.OK);
    }

    // Get coupon by ID
    @GetMapping("/{id}")
    public ResponseEntity<Coupon> getCouponById(@PathVariable Long id) {
        Optional<Coupon> coupon = couponService.getCouponById(id);
        return coupon.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update a coupon by ID
    @PutMapping("/{id}")
    public ResponseEntity<Coupon> updateCoupon(@PathVariable Long id, @RequestBody Coupon couponDetails) {
        Coupon updatedCoupon = couponService.updateCoupon(id, couponDetails);
        if (updatedCoupon != null) {
            return new ResponseEntity<>(updatedCoupon, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Delete a coupon by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCoupon(@PathVariable Long id) {
        if (couponService.deleteCoupon(id)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/validate")
    public ResponseEntity<List<Coupon>> validateCoupon(@RequestBody CouponRequest couponRequest) {
        // Convert the date string to LocalDateTime if necessary
        LocalDateTime expirationDate = LocalDateTime.parse(
                couponRequest.getExpirationDate().toString(),
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
        );

        // Pass the request to the service layer
        List<Coupon> applicableCoupons = couponService.findApplicableCoupons(couponRequest);
        return ResponseEntity.ok(applicableCoupons);
    }
    // Get applicable coupons based on CouponRequest
    @PostMapping("/applicable-coupons")
    public ResponseEntity<List<Coupon>> getApplicableCoupons(@RequestBody CouponRequest couponRequest) {
        logger.info("Received request to get applicable coupons.");
        try {
            List<Coupon> applicableCoupons = couponService.findApplicableCoupons(couponRequest);
            logger.info("Returning {} applicable coupons.", applicableCoupons.size());
            return new ResponseEntity<>(applicableCoupons, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            logger.error("Error processing request: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            logger.error("Unexpected error: ", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Apply coupon to cart
    @PostMapping("/apply-coupon/{id}")
    public ResponseEntity<Cart> applyCoupon(@PathVariable Long id, @RequestBody Cart cart) {
        try {
            Cart updatedCart = couponService.applyCouponToCart(id, cart);
            if (updatedCart != null) {
                return new ResponseEntity<>(updatedCart, HttpStatus.OK);
            }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
